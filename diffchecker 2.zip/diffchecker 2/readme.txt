DiffChecker:
==================
- This project focuses on performing diff checking on two list of objects with same data model. 
- The diff checking implementation is present in 'DiffChecker.java'.
- Its a generic checker which would work for any data model.

How to run this?
- Its a maven project and can be imported in any IDE. The class 'TaskExecutor.java' is the main class. 

Note: The jar of this project is intentionally not created as the dummy data is hard coded in TaskExceutor for demo purposes.

Key points:
==================
- The diff checker would only work if the first list is not empty. This is because the first list is taken as a reference and the second list is compared to it.
- The data model in the both the lists should be same for correct results. The program will not fail though.
- The report generator prepares the report in the project directory itself.