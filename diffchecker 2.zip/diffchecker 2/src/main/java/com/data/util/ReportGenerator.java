package com.data.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bson.Document;

/**
 * The utility ReportGenerator. It holds implementation to generate excel report
 * from the comparison result.
 */
public class ReportGenerator {

	private ReportGenerator() {
		// This is a utility class. Thus instantiation is not allowed.
	}

	/**
	 * Prepares the report
	 * 
	 * @param result The comparsion result.
	 */
	@SuppressWarnings("unchecked")
	public static void prepareReport(Document result) {

		if (!result.isEmpty()) {
			try (OutputStream fileOut = new FileOutputStream("result.xlsx"); Workbook workbook = new XSSFWorkbook();) {

				// The yellow color cell style. It will be used to highlight the cell.
				CellStyle style = workbook.createCellStyle();
				style.setFillBackgroundColor(IndexedColors.YELLOW.getIndex());
				style.setFillPattern(FillPatternType.LEAST_DOTS);

				Sheet workSheet = workbook.createSheet();
				List<String> headers = (List<String>) result.get("headers");
				List<Document> data = (List<Document>) result.get("data");
				int rowCount = 0;
				int totalHeaders = headers.size();

				// Setting the headers
				Row headerRow = workSheet.createRow(rowCount++);
				for (int i = 0; i < totalHeaders; i++) {
					Cell cell = headerRow.createCell(i);
					cell.setCellValue(headers.get(i));
				}

				for (Document row : data) {
					Row sheetRow = workSheet.createRow(rowCount++);
					for (int i = 0; i < totalHeaders; i++) {
						String header = headers.get(i);
						Cell cell = sheetRow.createCell(i);
						Document field = (Document) row.get(header);
						cell.setCellValue(field.getString("value"));

						if (field.getBoolean("highlight")) { // Highlighting the cell
							cell.setCellStyle(style);
						}
					}
				}

				workbook.write(fileOut);
			} catch (IOException exception) {
				System.out.println("Error: Report generation failed.");
			}
		} else {
			System.out.println("No data is present to prepare report.");
		}
	}
}
