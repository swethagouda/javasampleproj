package com.data.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.map.LinkedMap;
import org.bson.Document;

import com.google.gson.Gson;

/**
 * The utility DiffChecker. It holds implementation to perform diff on two lists
 * with same data type.
 */
public class DiffChecker<T> {

	// Note: Its constructor is not made private because The DiffChecker is made
	// generic. i.e. It would work for any data model.

	/**
	 * The Gson object. It converts any serializable object into JSON.
	 */
	private static final Gson GSON = new Gson();

	/**
	 * Processes the list of TranData and prepares a map of primary_key_set-> object
	 * JSON
	 * 
	 * @param list The list to process
	 * @return The prepared map
	 */
	private Map<String, Document> processList(List<T> list) {

		Map<String, Document> map = new LinkedMap<>();
		for (T tranData : list) {
			String dataJSON = GSON.toJson(tranData);
			map.put(tranData.toString(), Document.parse(dataJSON));
		}

		return map;
	}

	/**
	 * Compares the two lists
	 * 
	 * @param firstList  The first list
	 * @param secondList The second list
	 * @return The comparison result
	 */
	public Document compare(List<T> firstList, List<T> secondList) {

		if (!firstList.isEmpty()) {
			Map<String, Document> firstListMap = processList(firstList); // Processes first list
			Map<String, Document> secondListMap = processList(secondList); // Processes second list

			// The headers
			ArrayList<String> headers = new ArrayList<>(firstListMap.get(firstList.get(0).toString()).keySet());

			// Comparing the lists.
			List<Document> comparedRecords = new ArrayList<>(); // It holds the comparison results for each record

			for (Entry<String, Document> entry : firstListMap.entrySet()) { // Note: The first list is taken as
																			// reference
																			// and the second list will be compared to
																			// it.

				Document firstListRecord = entry.getValue();
				Document firstListRefactoredRecord = new Document(); // It holds all the keys from the first list record
																		// as it is but with additional 'highlighted'
																		// flag. If the flag is true, it would be
																		// highlighted in the report.
				Document secondListRefactoredRecord = new Document(); // It holds all the keys from the second list
																		// record as it is but with additional
																		// 'highlighted' flag. If the flag is true, it
																		// would be highlighted in the report.

				if (secondListMap.containsKey(entry.getKey())) {
					Document secondListRecord = secondListMap.get(entry.getKey());

					for (Entry<String, Object> recordEntry : firstListRecord.entrySet()) {
						Document firstListRefactoredField = new Document("value", recordEntry.getValue().toString()); // Copying
																														// actual
																														// data
																														// as
																														// it
																														// is
						Document secondListRefactoredField = new Document("value",
								secondListRecord.get(recordEntry.getKey()).toString()); // Copying the actual value as
																						// it is

						if (secondListRecord.containsKey(recordEntry.getKey())
								&& recordEntry.getValue().equals(secondListRecord.get(recordEntry.getKey()))) { // The
																												// field
																												// would
																												// be
																												// highlighted
																												// if is
																												// either
																												// not
																												// present
																												// in
																												// second
																												// list
																												// record
																												// or
																												// its
																												// value
																												// doesn't
																												// match
																												// with
																												// the
																												// later.
							firstListRefactoredField.append("highlight", false);
							secondListRefactoredField.append("highlight", false);
						} else {
							firstListRefactoredField.append("highlight", true);
							secondListRefactoredField.append("highlight", true);
						}

						firstListRefactoredRecord.put(recordEntry.getKey(), firstListRefactoredField);
						secondListRefactoredRecord.put(recordEntry.getKey(), secondListRefactoredField);
					}
				} else { // The entire row is not present in the second list
					for (Entry<String, Object> recordEntry : firstListRecord.entrySet()) {
						firstListRefactoredRecord.put(recordEntry.getKey(),
								new Document("value", recordEntry.getValue().toString()).append("highlight", true));
					}
					for (String header : headers) {
						secondListRefactoredRecord.put(header, new Document("value", "").append("highlight", true));
					}
				}

				firstListRefactoredRecord.put("origin", new Document("value", "list1").append("highlight", false));
				comparedRecords.add(firstListRefactoredRecord);
				secondListRefactoredRecord.put("origin", new Document("value", "list2").append("highlight", false));
				comparedRecords.add(secondListRefactoredRecord);
			}

			// Preparing the final response
			Document finalResponse = new Document();
			headers.add(0, "origin");
			finalResponse.append("data", comparedRecords).append("headers", headers);
			return finalResponse;
		}
		return new Document();
	}
}
