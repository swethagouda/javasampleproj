package com.data.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The utility DateComparator. It holds implementation to compare dates.
 */
public class DateComparator {

	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");

	private DateComparator() {
		// Its a utility class. Thus instantiation is now allowed.
	}

	/**
	 * Parses the date
	 * 
	 * @param dateString The date string
	 * @return The parsed date
	 */
	private static Date parseDate(String dateString) {

		try {
			return DATE_FORMAT.parse(dateString);
		} catch (ParseException parseException) {
			System.out.println("Error parsing date: " + dateString);
		}
		return null;
	}

	/**
	 * Validate and compare two date strings.
	 * 
	 * @param dateString1 The first date string
	 * @param dateString2 The second date string
	 * @return The comparison result
	 */
	public static boolean compare(String dateString1, String dateString2) {

		Date date1 = parseDate(dateString1);
		Date date2 = parseDate(dateString2);

		if (date1 == null || date2 == null || (date2.getTime() - date1.getTime()) > 432000000) { // 5 days = 432000000
																									// ms.
			return false;
		}
		return true;
	}
}
