package com.data.model;

import java.math.BigInteger;
import java.util.Date;

public class TranData {

	private String application;
	private String fromAcct;
	private String fromAcctIraCode;
	private BigInteger tranAmount;
	private String toAccount;
	private String regionCode;
	private String countryCode;
	private BigInteger maxLimit;
	private Double interestPercentage;
	private String errorText;
	private String errorType;
	private Date tranStrt;

	public TranData(String application, String fromAcct, String fromAcctIraCode, BigInteger tranAmount,
			String toAccount, String regionCode, String countryCode, BigInteger maxLimit, Double interestPercentage,
			String errorText, String errorType, Date tranStrt) {
		super();
		this.application = application;
		this.fromAcct = fromAcct;
		this.fromAcctIraCode = fromAcctIraCode;
		this.tranAmount = tranAmount;
		this.toAccount = toAccount;
		this.regionCode = regionCode;
		this.countryCode = countryCode;
		this.maxLimit = maxLimit;
		this.interestPercentage = interestPercentage;
		this.errorText = errorText;
		this.errorType = errorType;
		this.tranStrt = tranStrt;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getFromAcct() {
		return fromAcct;
	}

	public void setFromAcct(String fromAcct) {
		this.fromAcct = fromAcct;
	}

	public String getFromAcctIraCode() {
		return fromAcctIraCode;
	}

	public void setFromAcctIraCode(String fromAcctIraCode) {
		this.fromAcctIraCode = fromAcctIraCode;
	}

	public BigInteger getTranAmount() {
		return tranAmount;
	}

	public void setTranAmount(BigInteger tranAmount) {
		this.tranAmount = tranAmount;
	}

	public String getToAccount() {
		return toAccount;
	}

	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public BigInteger getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(BigInteger maxLimit) {
		this.maxLimit = maxLimit;
	}

	public Double getInterestPercentage() {
		return interestPercentage;
	}

	public void setInterestPercentage(Double interestPercentage) {
		this.interestPercentage = interestPercentage;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public Date getTranStrt() {
		return tranStrt;
	}

	public void setTranStrt(Date tranStrt) {
		this.tranStrt = tranStrt;
	}

	/**
	 * The string representation of TranData would only be the primary key set
	 * combined with a space. It would help uniquely identify a record.
	 */
	@Override
	public String toString() {

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(this.application);
		stringBuilder.append(" ");
		stringBuilder.append(this.fromAcct);
		stringBuilder.append(" ");
		stringBuilder.append(this.fromAcctIraCode);
		stringBuilder.append(" ");
		stringBuilder.append(this.tranAmount);
		stringBuilder.append(" ");
		stringBuilder.append(this.toAccount);
		return stringBuilder.toString();
	}
}
