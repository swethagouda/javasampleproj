package com.data;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.data.model.TranData;
import com.data.util.DiffChecker;
import com.data.util.ReportGenerator;

public class TaskExecutor {

	public static void main(String[] args) {

		List<TranData> list1 = new ArrayList<>();
		List<TranData> list2 = new ArrayList<>();

		// Adding some records to list1
		list1.add(new TranData("application I", "000", "IRA-A", new BigInteger("1000"), "Account-B", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list1.add(new TranData("application II", "000", "IRA-A", new BigInteger("3100"), "Account-C", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list1.add(new TranData("application III", "000", "IRA-A", new BigInteger("3000"), "Account-D", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list1.add(new TranData("application IV", "000", "IRA-A", new BigInteger("1200"), "Account-E", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list1.add(new TranData("application V", "000", "IRA-A", new BigInteger("1020"), "Account-F", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));

		// Adding some records to list2
		list2.add(new TranData("application I", "000", "IRA-A", new BigInteger("1000"), "Account-B", "Region-A",
				"Country-A", new BigInteger("100000"), 1.4, "None", "None", new Date()));
		list2.add(new TranData("application II", "000", "IRA-A", new BigInteger("3100"), "Account-C", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "Error-A", "None", new Date()));
		list2.add(new TranData("application III", "000", "IRA-A", new BigInteger("3001"), "Account-D", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list2.add(new TranData("application IV", "000", "IRA-A", new BigInteger("1200"), "Account-G", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));
		list2.add(new TranData("application V", "000", "IRA-A", new BigInteger("1020"), "Account-F", "Region-A",
				"Country-A", new BigInteger("100000"), 1.2, "None", "None", new Date()));

		// Comparing the two lists
		DiffChecker<TranData> diffChecker = new DiffChecker<>();
		Document result = diffChecker.compare(list1, list2);

		// Preparing report
		ReportGenerator.prepareReport(result);
	}
}
